# -*- coding: utf-8 -*-
"""
Created on Tue Dec 22 12:25:04 2020

@author: purama hareesha
"""

from flask import Flask, request, render_template
import numpy as np
import re
import requests

app=Flask(__name__)

def check(output):
    url = "https://image-to-text2.p.rapidapi.com/cloudVision/imageToText"
    
    querystring = {"source":output,"sourceType":"url"}
    
    payload = '''{\r\n   \"source\": "'''+output+'''",\r\n    \"sourceType\":\"url\"\r\n}'''
    headers = {
    'content-type': "application/json",
    'x-rapidapi-key': "3519c83749mshdbc54023a92584cp106be5jsn7f7ecd25686d",
    'x-rapidapi-host': "image-to-text2.p.rapidapi.com"
    }
    
    response = requests.request("POST", url, data=payload, headers=headers, params=querystring)
    
    print(response.text)
    return (response.json()['text'])

@app.route('/')
def home():
    return render_template('base.html')

#information Extractor page
@app.route('/predict',methods=['POST'])
def predict():
    output=request.form['output']
    text=check(output)
    return render_template('base.html',output=text)

if __name__=="__main__":
    app.run()